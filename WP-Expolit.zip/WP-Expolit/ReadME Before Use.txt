Hello
if you face any error 
open it with python 3.9.8 download it from their site

Listen Update The database info at Config.ini file
it requires database so make sure to set the database info
before you start scanning your results
for remote db you can use sites like db4free.net or amazon s3
the login details are the default config to your wordpress website
so update that too.
once you got some sites with wp-install setup
it will auto update database and upload the Hacked.zip file
you can replace with your own shell script. it need to work with 
wordpress else no use. it login into wordpress websites
it use the default config in the .ini file and login
then upload shell to it and save the links.

its clean source code. follow those details for better results!.